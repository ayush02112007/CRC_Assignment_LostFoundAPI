from sqlmodel import SQLModel, create_engine

DATABASE_URL = "sqlite:///./lost_found.db"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}
)


def create_db_and_tables():
    SQLModel.metadata.create_all(engine)